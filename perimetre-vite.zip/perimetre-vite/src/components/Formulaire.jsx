import React, { useState } from 'react';
import { TextField, Button, Box } from '@mui/material';

export default function Formulaire({ onAjouter }) {
  const [formData, setFormData] = useState({ nom: '', valeur: '' });

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onAjouter(formData);
    setFormData({ nom: '', valeur: '' });
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mb: 2 }}>
      <TextField
        name="nom"
        label="Nom"
        value={formData.nom}
        onChange={handleChange}
        sx={{ mr: 2 }}
      />
      <TextField
        name="valeur"
        label="Valeur"
        value={formData.valeur}
        onChange={handleChange}
        sx={{ mr: 2 }}
      />
      <Button type="submit" variant="contained">Ajouter / Valider</Button>
    </Box>
  );
}
