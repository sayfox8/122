import React from 'react';
import { Drawer, List, ListItem, ListItemText } from '@mui/material';

export default function Sidebar() {
  return (
    <Drawer variant="permanent" anchor="left">
      <List>
        <ListItem>
          <ListItemText primary="Périmètre" />
        </ListItem>
      </List>
    </Drawer>
  );
}
