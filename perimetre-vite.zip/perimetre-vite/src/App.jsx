import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Formulaire from './components/Formulaire';
import Tableau from './components/Tableau';

function App() {
  const [rows, setRows] = useState([]);
  const [idCounter, setIdCounter] = useState(1);

  const ajouterDonnee = (data) => {
    setRows((prev) => [...prev, { id: idCounter, ...data }]);
    setIdCounter(idCounter + 1);
  };

  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ padding: '20px', width: '100%' }}>
        <h1>Périmètre</h1>
        <Formulaire onAjouter={ajouterDonnee} />
        <Tableau rows={rows} />
      </div>
    </div>
  );
}

export default App;
